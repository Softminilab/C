//
//  1.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/4/27.
//

#include <stdio.h>

int main(int argc, const char *argv[]) {
//    float yc;
//    printf("请输入英寸值:");
//    
//    const float cm = 2.54;
//    scanf("%f", &yc);
//    
//    printf("你输入的英寸值是：%.3f\n", yc);
//    printf("对应的厘米是：%.3f\n", yc * cm);
//    return 0;
    
//    int a, b;
//    a = 5;
//    b = 2;
//    b = a; // 5
//    a = b; // 5
//    printf("%d %d\n",b , a);
//    return 0;
    
    int x, y;
    x = 10;
    y = 5;   /* 第7行 */
    y = x + y; /*第8行*/
    x = x*y;  /*第9行*/
    printf("%d %d\n", x, y);
    return 0;
}
