//
//  too_big.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/4/28.
//

#include <stdio.h>

int main(int argc, const char *argv[]) {
    int i = 2147483647;
    unsigned int j = 4294967295;
    printf("%d %d %d\n", i, i+1, i+2);
    printf("%u %u %u\n", j, j+1, j+2);
    return 0;
}
/*
 Output:
 2147483647 -2147483648 -2147483647
 4294967295 0 1
 
 解释:
 1. 可以把无符号整数j看作是汽车的里程表。当达到它能表示的最大值 时，会重新从起始点开始
 2. 整数 i 也是类似的情况。它们主要的区别是，在 超过最大值时，unsigned int 类型的变量 j 从 0开始;而int类型的变量i则从 −2147483648开始。
 
 溢出行为是未定义的行为，C 标准并未定义有符号类型的溢出规则。以 上描述的溢出行为比较有代表性，但是也可能会出现其他情况
 */



