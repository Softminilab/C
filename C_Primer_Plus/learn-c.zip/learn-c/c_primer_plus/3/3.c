//
//  3.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/4/30.
//

#include <stdio.h>
#include <limits.h>

//// 1
//int main(int argc, const char *argv[]) {
//    printf("INT_MAX %d\n", INT_MAX);
//    printf("INT_MIN %d\n", INT_MIN);
//    
//    printf("------------\n");
//    
//    int a = INT_MAX + 1;
//    printf("Overflow a %d \n", a);
//    
//    int b = INT_MIN - 1;
//    printf("Upflow b %d \n", b);
//    return 0;
//}

// 2
//int main(int argc, const char *argv[]) {
//    int ascii_value; // 声明一个整型变量来存储输入的 ASCII 码值
//
//    printf("请输入一个 ASCII 码值（如，66）：");
//
//    // 使用 %d 读取一个整数，并将其存储在 ascii_value 变量中
//    // 最好检查 scanf 的返回值，确保成功读取了一个整数
//    if (scanf("%d", &ascii_value) == 1) {
//        // 使用 %c 打印 ascii_value 对应的字符
//        // 同时打印输入的数值本身，让输出更清晰
//        printf("ASCII 码 %d 对应的字符是: %c\n", ascii_value, ascii_value);
//    } else {
//        // 如果 scanf 返回值不是 1，说明输入不是有效的整数
//        printf("输入错误，请输入一个有效的整数 ASCII 码值。\n");
//        // 可以选择性地清除输入缓冲区，以防影响后续可能的输入操作
//        // while(getchar() != '\n'); // 清除缓冲区直到换行符
//    }
//}

// 3
//int main(int argc, const char *argv[]) {
//    printf("Startled by the sudden sound, Sally shouted,\n");
//    printf("\"By the Great Pumpkin, what was that!\"\n");
//    return 0;
//}

// 4
//int main(int argc, const char *argv[]) {
//    float float_value;
//    printf("Enter a floating-point value: ");
//    scanf("%f", &float_value);
//    printf("fixed-point notation: %f\n", float_value);
//    printf("exponential notation: %ef\n", float_value);
//    printf("p notation: %a\n", float_value);
//    return 0;
//}

// 5
int main(int argc, const char *argv[]) {
    float s_of_year = 3.156E7;
    double age;
    printf("请输入您的年龄：");
    scanf("%lf", &age);
    printf("您的年龄是：%.2f 岁, 对应的秒数是：%.4f", age, age * s_of_year);
    return 0;
}
