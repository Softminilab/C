//
//  p_3.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/4/17.
//

#include <stdio.h>

void swap(int *a, int *b) {
    int t = *a;
    *a = *b;
    *b = t;
}

//int main(int argc, char *argv[]) {
//    printf("请输入三个数：");
//    int a, b, c;
//    scanf("%d %d %d", &a, &b, &c);
//    
//    if (a > b) {
//        swap(&a, &b);
//    }
//    
//    if (a > c) {
//        swap(&a, &c);
//    }
//    
//    if (b > c) {
//        swap(&b, &c);
//    }
//    
//    printf("从小到大顺序为: %d %d %d\n", a, b, c);
//    return 0;
//}
