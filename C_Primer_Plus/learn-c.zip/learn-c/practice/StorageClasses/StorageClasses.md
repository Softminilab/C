#  Storage classes in C
### auto
这是函数或块内声明的所有变量的默认存储类。自动变量只能在声明它们的块/函数内访问，而不能在声明它们的块/函数外访问（这定义了它们的作用域）
* Scope: Local
* Default Value: Garbage Value
* Memory Location: RAM
* Lifetime: Till the end of its scope

```C
#include <stdio.h>

int main() {
  
    // auto is optional here, as it's the default storage class
    auto int x = 10;  
    printf("%d", x);
    return 0;
}
```
说明： auto 关键字用于声明具有自动存储的局部变量。但是在 C 语言中，局部变量默认为自动存储，因此是否指定 auto 是可选的。

### registe
此存储类声明的寄存器变量具有与自动变量相同的功能。唯一的区别是，如果有空闲的寄存器，编译器会尝试将这些变量存储在微处理器的寄存器中，这使得它比任何其他变量都快得多。
* Scope: Local
* Default Value: Garbage Value
* Memory Location: CPU 或 RAM 中的寄存器
* Lifetime: Till the end of its scope
```C
#include <stdio.h>

int main() {
  
    // Suggest to store in a register
    register int i;  
    for (i = 0; i < 5; i++) {
        printf("%d ", i);
    }
    return 0;
}

```
解释： register 关键字建议将变量存储在寄存器中以便更快地访问，但编译器可能并不总是根据可用的 CPU 寄存器来满足此请求。

### static
此存储类用于声明静态变量，这些变量具有即使超出其范围后仍保留其值的属性！因此，静态变量会保留其作用域内最后一次使用时的值。
* Scope: Local
* Default Value: Zero
* Memory Location: RAM
* Lifetime: Till the end of the program
```C
#include <stdio.h>
void counter() {
  
    // Static variable retains value between calls
    static int count = 0;  
    count++;
    printf("Count = %d\n", count);
}
int main() {
  
    // Prints: Count = 1
    counter();  
  
    // Prints: Count = 2
    counter(); 
    return 0;
}

```
解释： 静态变量 count 在函数调用之间保留其值。与每次函数调用时都会重新初始化的局部变量不同，静态变量会记住其先前的值。

### extern
外部存储类只是告诉我们变量是在其他地方定义的，而不是在使用它的同一个块中。基本上，该值是在不同的块中赋值的，并且可以在不同的块中覆盖/更改。
* Scope: Global
* Default Value: Zero
* Memory Location: RAM
* Lifetime: Till the end of the program.

printVar.c
```C
// Global variable declaration
int globalVar;  
```

另一个文件将此变量声明为 extern static，该变量已在另一个文件中声明。然后打印此变量。

main.c
```C
#include <stdio.h>

// Global variable
int globalVar = 100;  

void printGlobalVar();

int main() {
  
    // Prints: Global variable is: 100
    printGlobalVar(); 
    return 0;
}

```

### Summary  概括
![](Storage-Classes-in-C.webp)
