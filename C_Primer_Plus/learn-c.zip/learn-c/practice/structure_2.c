//
//  structure_2.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/4/22.
//

#include <stdio.h>
#include <string.h>

struct Student {
    int id;
    int name_len;
    int struct_size;
    char stu_name[];
};

int main(int argc, const char *argv[]) {
    struct Student s;
    printf("struct size %lu \n", sizeof(s));
    
    // The size of structure is = 4 + 4 + 4 + 0 = 12

    int len = strlen("Kartik");
    printf("len %d\n", len);
    
    char a[] = "Cherry";
    printf("strlen(a) %lu\n", strlen(a));
    
    return 0;
}
