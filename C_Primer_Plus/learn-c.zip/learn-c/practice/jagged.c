//
//  jagged.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/4/21.
//

#include <stdio.h>
#include <stdlib.h>

int main(int argc, const char * argv[]) {
    
    int* jagged[2];
    
    jagged[0] = malloc(2 * sizeof(int));
    jagged[1] = malloc(3 * sizeof(int));
    
    int size[2] = {2, 3}, k = 0, number = 100;
    
    for (size_t i = 0; i < 2; i++) {
        
        int* p = jagged[i];
        for (size_t j = 0; j < size[i]; j++) {
            *p = number++;
            
            p++;
        }
        k++;
    }
    
    k = 0;
    
    for (size_t i = 0; i < 2; i++) {
        int* p = jagged[i];
        for (size_t j = 0; j<size[k]; j++) {
            printf("%d \n", *p);
            p++;
        }
        k++;
    }
    
    return 0;
}
