//
//  char_c.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/4/16.
//

#include <stdio.h>

void char_c(void) {
    char c[] = "1234567";
    for (size_t i=0; i<sizeof(c)/sizeof(c[0]); i++) {
        printf("%d \n", c[i]);
    }
}
