//
//  struct_c.c
//  learn-c
//
//  Created by 0x2ab70001b1 on 2025/4/16.
//

#include <stdio.h>

struct SIMPLE {
    char title[50];
    char subject[100];
    int book_id;
} simple = {"C语言", "计算机科学", 121212};

struct T1 {
    int a;
    int b;
};

struct SIMPLE t1, t2[20], *t3;

struct T3;

struct T2 {
    struct T3 *t3;
    char name[100];
};

struct T3 {
    struct T2 *t2;
    char name[100];
};

void change_value(void);

void struct_c(void) {
    printf("simple.title %s\n", simple.title);
    printf("simple.subject %s\n", simple.subject);
    printf("simple.book_id %d\n", simple.book_id);
    
    change_value();
}

//snprintf() (来自 <stdio.h>)：
//安全：推荐使用。它会确保缓冲区不溢出，并且总是会添加空终止符（只要缓冲区大小大于 0）。
//用法：snprintf(destination_array, size, "%s", source_string); （size 是目标数组的总大小）
void change_value(void) {
    printf("sizeof(simple.title) %lu\n", sizeof(simple.title));
    snprintf(simple.title, sizeof(simple.title), "Swift");
    snprintf(simple.subject, sizeof(simple.subject), "计算机科学与技术");
    simple.book_id = 123456789;
}
